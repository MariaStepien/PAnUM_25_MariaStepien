package com.example.cafeappdatabase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

public class CoffeeShopDatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "coffeeshop";
    private static final int DB_VERSION = 5;

    CoffeeShopDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        updateMyDatabase(db, 0, DB_VERSION);
    }

    @Override
    public void onUpgrade (SQLiteDatabase db,int oldVersion, int newVersion) {
        updateMyDatabase(db, oldVersion, newVersion);
    }

    private static void insertDrink(SQLiteDatabase db, String name, String description, int resourceId, String price) {
        ContentValues drinkValues = new ContentValues();
        drinkValues.put("NAME", name);
        drinkValues.put("DESCRIPTION", description);
        drinkValues.put("IMAGE_RES_ID", resourceId);
        drinkValues.put("PRICE", price);
        db.insert("DRINK", null, drinkValues);
    }

    private static void insertSnack(SQLiteDatabase db, String name, String description, int resourceId, String price) {
        ContentValues snackValues = new ContentValues();
        snackValues.put("NAME", name);
        snackValues.put("DESCRIPTION", description);
        snackValues.put("IMAGE_RES_ID", resourceId);
        snackValues.put("PRICE", price);
        db.insert("SNACK", null, snackValues);
    }

    private static void insertLocation(SQLiteDatabase db, String name, String address, String openingHours, int resourceId) {
        ContentValues locationValues = new ContentValues();
        locationValues.put("NAME", name);
        locationValues.put("ADDRESS", address);
        locationValues.put("OPENING_HOURS", openingHours);
        locationValues.put("IMAGE_RES_ID", resourceId);
        db.insert("LOCATION", null, locationValues);
    }
    private void updateMyDatabase(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 1) {
            db.execSQL("CREATE TABLE DRINK (_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "NAME TEXT,"
                    + "DESCRIPTION TEXT,"
                    + "IMAGE_RES_ID INTEGER,"
                    + "PRICE TEXT);");
            insertDrink(db, "Latte", " Włoski napój kawowy powstający w wyniku wlania spienionego ciepłego mleka do kawy espresso.", R.drawable.latte, "5.70");
            insertDrink(db, "Cappuccino", "Włoski napój kawowy z dodatkiem spienionego mleka i szczyptą sypkiej czekolady lub kakao dla ozdoby. ", R.drawable.filizanka_cappuccino, "7.90");
            insertDrink(db, "Herbata malinowa", "Herbata malinowa z dodatkiem miodu.", R.drawable.herbmalinowa, "8.50");
            insertDrink(db, "Kawa czarna", "Czarna kawa z prażonych nasion.", R.drawable.kawa, "6.50");

        }
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE SNACK (_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "NAME TEXT,"
                    + "DESCRIPTION TEXT,"
                    + "IMAGE_RES_ID INTEGER,"
                    + "PRICE TEXT);");
            insertSnack(db, "Ciasto truskawkowe","Jasny biszkopt z bitą śmietaną, kawałkami truskawek i galaretką truskawkową.", R.drawable.ciasto_z_galaretka, "14.90");
            insertSnack(db, "Sernik","Sernik na zimno rosa z dodatkiem migdałów.", R.drawable.sernik_z_rosa_01_0, "13.50");
            insertSnack(db, "Kanapka","Kanapka z chleba żytniego, wędliny, sałaty i pomidora.", R.drawable.kanapki_z_szynka_i_majonezem_zrob_najlepsze_na_swiecie_2439550, "7.80");
            insertSnack(db, "Biszkoptowe ciastka z makiem", "Biszkoptowe ciasteczka z makiem nadziane dżemem truskawkowym. (10szt.)",R.drawable.biszkoptowe_ciasteczka_z_makiem, "10.50");
        }
        if (oldVersion < 3) {
            db.execSQL("CREATE TABLE LOCATION (_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "NAME TEXT,"
                    + "ADDRESS TEXT,"
                    + "OPENING_HOURS TEXT,"
                    + "IMAGE_RES_ID INTEGER);");
            insertLocation(db, "Coffee Shop, City 1","Street 1 City 1 42-000", "pon: zamknięte\nwt: 10-17\nśr: 10-17\nczw: 10-17\npt: 10-17\nsb: 10-14\nndz: 10-14", R.drawable.map1);
            insertLocation(db, "Coffee Shop2, City 2","Street 2 City 2 42-000", "pon: zamknięte\nwt: 10-17\nśr: 10-17\nczw: 10-17\npt: 10-17\nsb: 10-14\nndz: 10-14", R.drawable.map2);
            insertLocation(db, "Coffee Shop3, City 3","Street 3 City 3 42-000", "pon: zamknięte\nwt: 10-17\nśr: 10-17\nczw: 10-17\npt: 10-17\nsb: 10-14\nndz: 10-14", R.drawable.map3);
            insertLocation(db, "Coffee Shop4, City 4", "Street 4 City 4 42-200","pon: zamknięte\nwt: 10-17\nśr: 10-17\nczw: 10-17\npt: 10-17\nsb: 10-14\nndz: 10-14", R.drawable.map4);
        }

        if (oldVersion < 4) {
            db.execSQL("UPDATE SNACK SET PRICE = '14.90' WHERE NAME = 'Ciasto truskawkowe'");
            db.execSQL("UPDATE SNACK SET PRICE = '13.50' WHERE NAME = 'Sernik'");
            db.execSQL("UPDATE SNACK SET PRICE = '7.80' WHERE NAME = 'Kanapka'");
            db.execSQL("UPDATE SNACK SET PRICE = '10.50' WHERE NAME = 'Biszkoptowe ciastka z makiem'");

            db.execSQL("UPDATE DRINK SET PRICE = '5.70' WHERE NAME = 'Latte'");
            db.execSQL("UPDATE DRINK SET PRICE = '7.90' WHERE NAME = 'Cappuccino'");
            db.execSQL("UPDATE DRINK SET PRICE = '8.50' WHERE NAME = 'Herbata malinowa'");
            db.execSQL("UPDATE DRINK SET PRICE = '6.50' WHERE NAME = 'Kawa czarna'");
        }
    }

}

