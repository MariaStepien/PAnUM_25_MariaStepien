package com.example.cafeappdatabase;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LocationActivity extends AppCompatActivity {

    public static final String EXTRA_LOCATIONID = "locationId";
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        int locationId = (Integer)getIntent().getExtras().get(EXTRA_LOCATIONID);
        SQLiteOpenHelper starbuzzDatabaseHelper = new CoffeeShopDatabaseHelper(this);
        try {
            SQLiteDatabase db = starbuzzDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query ("LOCATION", new String[] {"NAME", "ADDRESS", "OPENING_HOURS", "IMAGE_RES_ID"}, "_id = ?", new String[] {Integer.toString(locationId)},
                    null, null, null);
            if (cursor.moveToFirst()) {
                String nameText = cursor.getString(0);
                String addressText = cursor.getString(1);
                String openingHoursText = cursor.getString(2);
                int photoId = cursor.getInt(3);

                TextView name = (TextView)findViewById(R.id.name);
                name.setText(nameText);

                TextView address = (TextView)findViewById(R.id.address);
                address.setText(addressText);

                TextView openingHours = (TextView)findViewById(R.id.openingHours);
                openingHours.setText(openingHoursText);

                ImageView photo = (ImageView)findViewById(R.id.photo);
                photo.setImageResource(photoId);
                photo.setContentDescription(nameText);
            }
            cursor.close();
            db.close();
        } catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Baza danych jest niedostępna", Toast.LENGTH_SHORT);
            toast.show();
        }
    }
}