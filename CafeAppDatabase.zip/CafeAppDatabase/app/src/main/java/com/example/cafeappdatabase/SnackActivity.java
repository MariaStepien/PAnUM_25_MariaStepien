package com.example.cafeappdatabase;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SnackActivity extends AppCompatActivity {

    public static final String EXTRA_SNACKID = "snackId";
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snack);
        int snackId = (Integer)getIntent().getExtras().get(EXTRA_SNACKID);
        SQLiteOpenHelper starbuzzDatabaseHelper = new CoffeeShopDatabaseHelper(this);
        try {
            SQLiteDatabase db = starbuzzDatabaseHelper.getReadableDatabase();
            Cursor cursor = db.query ("SNACK", new String[] {"NAME", "DESCRIPTION", "IMAGE_RES_ID", "PRICE"}, "_id = ?", new String[] {Integer.toString(snackId)},
                    null, null, null);
            if (cursor.moveToFirst()) {
                String nameText = cursor.getString(0);
                String descriptionText = cursor.getString(1);
                int photoId = cursor.getInt(2);
                String priceText = cursor.getString(3);

                TextView name = (TextView)findViewById(R.id.name);
                name.setText(nameText);

                TextView description = (TextView)findViewById(R.id.description);
                description.setText(descriptionText);

                ImageView photo = (ImageView)findViewById(R.id.photo);
                photo.setImageResource(photoId);
                photo.setContentDescription(nameText);

                TextView price = (TextView)findViewById(R.id.price);
                price.setText("Cena: " + priceText + " zł");
            }
            cursor.close();
            db.close();
        } catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Baza danych jest niedostępna", Toast.LENGTH_SHORT);
            toast.show();
        }
    }
    public void onClickMinus(View view) {
        TextView textView = (TextView) findViewById(R.id.amountId);
        String text = (String) textView.getText();
        int amount = Integer.parseInt(text);

        if (amount > 0) {
            amount--;
        }
        textView.setText(Integer.toString(amount));
    }

    public void onClickPlus(View view) {
        TextView textView = (TextView) findViewById(R.id.amountId);
        String text = (String) textView.getText();
        int amount = Integer.parseInt(text);

        if (amount >= 0) {
            amount++;
        }
        textView.setText(Integer.toString(amount));
    }

    public void onClickAddToChart(View view) {
        int snackId = getIntent().getIntExtra(EXTRA_SNACKID, -1);
        if (snackId == -1) {
            Toast.makeText(this, "Błąd: nie znaleziono przekąski", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteOpenHelper databaseHelper = new CoffeeShopDatabaseHelper(this);
        try {
            SQLiteDatabase db = databaseHelper.getReadableDatabase();
            Cursor cursor = db.query(
                    "SNACK",
                    new String[]{"NAME", "PRICE"},
                    "_id = ?",
                    new String[]{String.valueOf(snackId)},
                    null, null, null
            );

            if (cursor.moveToFirst()) {
                String itemName = cursor.getString(0);
                double price = cursor.getDouble(1);

                TextView textView = findViewById(R.id.amountId);
                int quantity = Integer.parseInt(textView.getText().toString());

                if (quantity > 0) {
                    Order.getInstance().addItem(itemName, quantity, price);
                    Toast.makeText(this, itemName + " dodano do zamówienia", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Wybierz ilość większą niż 0", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Nie znaleziono przekąski", Toast.LENGTH_SHORT).show();
            }

            cursor.close();
            db.close();
        } catch (SQLiteException e) {
            Toast.makeText(this, "Błąd bazy danych", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Nieprawidłowa ilość", Toast.LENGTH_SHORT).show();
        }
    }
}