package com.example.timercountdown;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private int seconds = 0;
    private int hundredths = 0;
    private boolean running;

    private int seconds2 = 0;
    private int hundredths2 = 0;
    private boolean running2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        runTimer();
    }

    public void switchToCountDown(View view) {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    public void onClickStartButton(View view) {
        if (view.getId() == R.id.startButton) {
            running = true;
        }

        if (view.getId() == R.id.startButton2) {
            running2 = true;
        }
    }

    public void onClickStopButton(View view) {
        if (view.getId() == R.id.stopButton) {
            running = false;
        }

        if (view.getId() == R.id.stopButton2) {
            running2 = false;
        }
    }

    public void onClickResetButton(View view) {
        if (view.getId() == R.id.resetButton) {
            running = false;
            seconds = 0;
            hundredths = 0;
        }

        if (view.getId() == R.id.resetButton2) {
            running2 = false;
            seconds2 = 0;
            hundredths2 = 0;
        }
    }

    public void runTimer() {
        TextView timeView = findViewById(R.id.textView_screen);
        TextView timeView2 = findViewById(R.id.textView_screen2);

        final Handler handler = new Handler();
        final Handler handler2 = new Handler();

        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = seconds / 3600;
                int minutes = (seconds % 3600) / 60;
                int secs = seconds % 60;
                String time = String.format(Locale.US, "%d:%02d:%02d.%d", hours, minutes, secs, hundredths);
                timeView.setText(time);
                if (running) {
                    ++hundredths;
                    if (hundredths == 10) {
                        seconds++;
                        hundredths = 0;
                    }
                }
                handler.postDelayed(this, 100);
            }
        });

        handler2.post(new Runnable() {
            @Override
            public void run() {
                int hours = seconds2 / 3600;
                int minutes = (seconds2 % 3600) / 60;
                int secs = seconds2 % 60;
                String time = String.format(Locale.US, "%d:%02d:%02d.%d", hours, minutes, secs, hundredths2);
                timeView2.setText(time);
                if (running2) {
                    ++hundredths2;
                    if (hundredths2 == 10) {
                        seconds2++;
                        hundredths2 = 0;
                    }
                }
                handler2.postDelayed(this, 100);
            }
        });

    }

}