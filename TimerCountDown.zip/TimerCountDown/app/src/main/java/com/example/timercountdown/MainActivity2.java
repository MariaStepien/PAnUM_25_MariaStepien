package com.example.timercountdown;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {
    private boolean running = false;
    private boolean running2 = false;
    private int seconds = 0;
    private int seconds2 = 0;
    private Handler handler = new Handler();

    private TextView timeView, timeView2;
    private EditText inputHours, inputMin, inputSec;
    private EditText inputHours2, inputMin2, inputSec2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        timeView = findViewById(R.id.textViewCountdown);
        timeView2 = findViewById(R.id.textViewCountdown2);

        inputHours = findViewById(R.id.editTextHours);
        inputMin = findViewById(R.id.editTextMinutes);
        inputSec = findViewById(R.id.editTextSeconds);

        inputHours2 = findViewById(R.id.editTextHours2);
        inputMin2 = findViewById(R.id.editTextMinutes2);
        inputSec2 = findViewById(R.id.editTextSeconds2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        runCountDown();
    }

    public void onClickStart(View view) {
        if (view.getId() == R.id.startButton && !running) {
            seconds = getInputTime(inputHours, inputMin, inputSec);
            if (seconds > 0) {
                running = true;
            } else {
                Toast.makeText(this, "Enter valid time for Timer 1!", Toast.LENGTH_SHORT).show();
            }
        }

        if (view.getId() == R.id.startButton2 && !running2) {
            seconds2 = getInputTime(inputHours2, inputMin2, inputSec2);
            if (seconds2 > 0) {
                running2 = true;
            } else {
                Toast.makeText(this, "Enter valid time for Timer 2!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void onClickStop(View view) {
        if (view.getId() == R.id.stopButton) {
            running = false;
        }
        if (view.getId() == R.id.stopButton2) {
            running2 = false;
        }
    }

    public void onClickReset(View view) {
        if (view.getId() == R.id.resetButton) {
            running = false;
            seconds = 0;
            timeView.setText("00:00:00");
            clearInputs(inputHours, inputMin, inputSec);
        }
        if (view.getId() == R.id.resetButton2) {
            running2 = false;
            seconds2 = 0;
            timeView2.setText("00:00:00");
            clearInputs(inputHours2, inputMin2, inputSec2);
        }
    }

    private void runCountDown() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (running && seconds > 0) {
                    seconds--;
                }
                if (running2 && seconds2 > 0) {
                    seconds2--;
                }

                timeView.setText(formatTime(seconds));
                timeView2.setText(formatTime(seconds2));

                handler.postDelayed(this, 1000);
            }
        });
    }

    private int getInputTime(EditText hoursInput, EditText minutesInput, EditText secondsInput) {
        int hours = parseIntOrZero(hoursInput.getText().toString());
        int minutes = parseIntOrZero(minutesInput.getText().toString());
        int seconds = parseIntOrZero(secondsInput.getText().toString());

        return (hours * 3600) + (minutes * 60) + seconds;
    }


    private void clearInputs(EditText hours, EditText minutes, EditText seconds) {
        hours.setText("");
        minutes.setText("");
        seconds.setText("");
    }

    private int parseIntOrZero(String text) {
        if (text.isEmpty()) {
            return 0;
        }
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String formatTime(int totalSeconds) {
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds);
    }

    public void switchToTimer(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}