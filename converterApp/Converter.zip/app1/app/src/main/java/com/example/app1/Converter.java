package com.example.app1;

import androidx.appcompat.app.AppCompatActivity;

public class Converter extends AppCompatActivity {
    private static final int[] VALUES =
            {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    private static final String[] SYMBOLS =
            {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    public static String convertToRoman(String arabicNumber) {
        int number;
        try {
            number = Integer.parseInt(arabicNumber);
        } catch (NumberFormatException e) {
            return "";
        }

        if (number > 3999) {
            return "Invalid input: number has to be in range 1-3999.";
        }

        if (number == 0) {
            return "";
        }

        StringBuilder roman = new StringBuilder();
        for (int i = 0; i < VALUES.length; i++) {
            while (number >= VALUES[i]) {
                roman.append(SYMBOLS[i]);
                number -= VALUES[i];
            }
        }
        return roman.toString();
    }
    public static String convertToArabic(String roman) {
        if (roman == null || roman.isEmpty()) {
            return "";
        }

        int result = 0;
        int lastValue = 0;
        int repeatCount = 0;
        char lastChar = '\0';
        int countV = 0, countL = 0, countD = 0, countI = 0;
        boolean usedSubtractive = false; // czy ostatnia para liczb rzymskich byla CM, CD...
        boolean numeralsEnder = false;  // czy ciag liczb rzymskich konczy sie IX lub IV

        for (int i = 0; i < roman.length(); i++) {
            char currentChar = roman.charAt(i);
            int currentValue = getValue(currentChar);

            if (currentValue == -1) {
                return "Invalid input: contains non-Roman numeral characters.";
            }

            if (roman.length() > 2 && i >= 2) {
                if (isCorrectOrder(roman.charAt(i-2), lastChar) && lastChar == currentChar) {
                    return "Invalid input: incorrect order of numerals.";
                }
            }

            if (lastValue != 0 && lastValue < currentValue) {
                if (usedSubtractive) {
                    return "Invalid input: multiple subtractive notations in sequence.";
                }
                if (!isCorrectOrder(lastChar, currentChar)) {
                    return "Invalid input: incorrect order of numerals.";
                }
                usedSubtractive = true;

                if ((lastChar == 'I' && (currentChar == 'X' || currentChar == 'V'))) {
                    numeralsEnder = true;
                }
            } else {
                usedSubtractive = false;
            }

            if (currentChar == 'V') countV++;
            if (currentChar == 'L') countL++;
            if (currentChar == 'D') countD++;
            if (countV > 1 || countL > 1 || countD > 1) {
                return "Invalid input: V, L, and D cannot appear more than once.";
            }
            if (countV == 1 && (currentChar != 'V' && currentChar != 'I')) {
                return "Invalid input: incorrect order of numerals.";
            }

            if (numeralsEnder && (lastChar == 'X' || lastChar == 'V')) {
                return "Invalid input: no numerals allowed after IX or IV.";
            }
            if (currentChar == 'I') {
                countI++;
            }
            if (currentChar != 'I' && countI > 1) {
                return "Invalid input: incorrect repetition of numerals.";
            }

            if (currentChar == lastChar) {
                repeatCount++;

                if (repeatCount == 3) {
                    return "Invalid input: incorrect repetition of numerals.";
                }
            } else {
                repeatCount = 0;
            }

            if (lastValue < currentValue) {
                result += currentValue - 2 * lastValue;
            } else {
                result += currentValue;
            }

            lastValue = currentValue;
            lastChar = currentChar;
        }

        return Integer.toString(result);
    }

    private static boolean isCorrectOrder(char first, char second) {
        String pair = "" + first + second;
        String[] validPairs = {"IV", "IX", "XL", "XC", "CD", "CM"};

        for (String valid : validPairs) {
            if (pair.equals(valid)) {
                return true;
            }
        }
        return false;
    }

    private static int getValue(char romanChar) {
        switch (romanChar) {
            case 'M': return 1000;
            case 'D': return 500;
            case 'C': return 100;
            case 'L': return 50;
            case 'X': return 10;
            case 'V': return 5;
            case 'I': return 1;
            default: return -1;
        }
    }
}

// 1921 = MCMXXI