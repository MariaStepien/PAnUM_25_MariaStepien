package com.example.runnerapp;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextPace, editTextSpeed, editTextDistance, editTextHours, editTextMin, editTextSec;
    private TextView textViewResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPace = findViewById(R.id.editTextPace);
        editTextSpeed = findViewById(R.id.editTextSpeed);
        editTextDistance = findViewById(R.id.editTextDistance);
        editTextHours = findViewById(R.id.editTextHours);
        editTextMin = findViewById(R.id.editTextMin);
        editTextSec = findViewById(R.id.editTextSec);
        textViewResults = findViewById(R.id.textViewResults);
    }

    public void calculateSpeed(View view) {
        String paceInput = editTextPace.getText().toString();
        if (!paceInput.isEmpty()) {
            double pace = Double.parseDouble(paceInput);
            double speed = 60 / pace;
            displayResults("Prędkość: " + String.format("%.2f km/h", speed));
        }
    }

    public void calculatePace(View view) {
        String speedInput = editTextSpeed.getText().toString();
        if (!speedInput.isEmpty()) {
            double speed = Double.parseDouble(speedInput);
            double pace = 60 / speed;
            displayResults("Tempo: " + String.format("%.2f min/km", pace));
        }
    }

    public void calculateTimeForDistance(View view) {
        String paceInput = editTextPace.getText().toString();
        String distanceInput = editTextDistance.getText().toString();

        if (!paceInput.isEmpty() && !distanceInput.isEmpty()) {
            double pace = Double.parseDouble(paceInput);
            double distance = Double.parseDouble(distanceInput);

            int totalSeconds = (int) (pace * 60 * distance);
            String formattedTime = formatTime(totalSeconds);
            displayResults("Czas na " + distance + " km: " + formattedTime);
        }
    }

    public void calculateRaceTimes(View view) {
        String paceInput = editTextPace.getText().toString();

        if (!paceInput.isEmpty()) {
            double pace = Double.parseDouble(paceInput);

            int marathonTime = (int) (pace * 60 * 42.195);
            int halfMarathonTime = (int) (pace * 60 * 21.0975);

            String marathonFormatted = formatTime(marathonTime);
            String halfMarathonFormatted = formatTime(halfMarathonTime);

            displayResults("Maraton: " + marathonFormatted + "\nPółmaraton: " + halfMarathonFormatted);
        }
    }

    public void calculateRequiredPaceSpeed(View view) {
        String distanceInput = editTextDistance.getText().toString();
        String hoursInput = editTextHours.getText().toString();
        String minutesInput = editTextMin.getText().toString();
        String secondsInput = editTextSec.getText().toString();

        if (!distanceInput.isEmpty() && (!hoursInput.isEmpty() || !minutesInput.isEmpty() || !secondsInput.isEmpty())) {
            double distance = Double.parseDouble(distanceInput);
            int hours = hoursInput.isEmpty() ? 0 : Integer.parseInt(hoursInput);
            int minutes = minutesInput.isEmpty() ? 0 : Integer.parseInt(minutesInput);
            int seconds = secondsInput.isEmpty() ? 0 : Integer.parseInt(secondsInput);

            int totalSeconds = (hours * 3600) + (minutes * 60) + seconds;
            double pace = (double) totalSeconds / 60 / distance;
            double speed = distance / ((double) totalSeconds / 3600);

            displayResults("Tempo: " + String.format("%.2f min/km", pace) +
                    "\nPrędkość: " + String.format("%.2f km/h", speed));
        }
    }

    private String formatTime(int totalSeconds) {
        int hours = totalSeconds / 3600;
        int minutes = (totalSeconds % 3600) / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    private void displayResults(String result) {
        textViewResults.setText(result);
    }
}